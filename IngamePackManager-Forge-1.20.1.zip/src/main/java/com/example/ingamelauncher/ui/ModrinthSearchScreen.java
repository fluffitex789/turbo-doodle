package com.example.ingamelauncher.ui;

import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;
import net.minecraft.client.Minecraft;

import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.util.*;
import com.google.gson.*;

public class ModrinthSearchScreen extends Screen {
    private final Screen parent;
    private EditBox queryBox;
    private List<Project> results = new ArrayList<>();
    private int selected = -1;

    public ModrinthSearchScreen(Screen parent) {
        super(Component.literal("Modrinth Suche"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int x = 20; int y = 40; int w = 240;
        queryBox = new EditBox(this.font, x, y, w, 20, Component.literal("Suche..."));
        addRenderableWidget(queryBox);
        addRenderableWidget(Button.builder(Component.literal("Suchen"), b -> doSearch()).bounds(x + w + 10, y, 80, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Installieren"), b -> installSelected()).bounds(x, y + 26, 120, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Zurück"), b -> this.minecraft.setScreen(parent)).bounds(x, this.height - 30, 100, 20).build());
    }

    private void doSearch() {
        results.clear();
        selected = -1;
        try {
            String q = URLEncoder.encode(queryBox.getValue(), java.nio.charset.StandardCharsets.UTF_8);
            // Filter: game versions & forge loader
            String url = "https://api.modrinth.com/v2/search?query=" + q + "&facets="
                + URLEncoder.encode("[["project_type:mod"],["versions:1.20.1"],["categories:forge"]]", java.nio.charset.StandardCharsets.UTF_8);
            var conn = new URL(url).openConnection();
            conn.setRequestProperty("User-Agent", "IngamePackManager/0.1");
            try (var in = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
                var json = JsonParser.parseReader(in).getAsJsonObject();
                var hits = json.getAsJsonArray("hits");
                for (var el : hits) {
                    var o = el.getAsJsonObject();
                    results.add(new Project(
                        o.get("project_id").getAsString(),
                        o.get("title").getAsString()
                    ));
                }
            }
        } catch (Exception e) {
            this.minecraft.player.displayClientMessage(Component.literal("Fehler: " + e.getMessage()), false);
        }
    }

    private void installSelected() {
        if (selected < 0 || selected >= results.size()) return;
        var prj = results.get(selected);
        try {
            // fetch versions for project, pick latest Forge+1.20.1 file
            String url = "https://api.modrinth.com/v2/project/" + prj.id + "/version?game_versions=["1.20.1"]&loaders=["forge"]";
            var conn = new URL(url).openConnection();
            conn.setRequestProperty("User-Agent", "IngamePackManager/0.1");
            try (var in = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
                var arr = JsonParser.parseReader(in).getAsJsonArray();
                if (arr.size() == 0) { throw new IOException("Keine passende Version gefunden."); }
                var ver = arr.get(0).getAsJsonObject();
                var files = ver.getAsJsonArray("files");
                if (files.size() == 0) { throw new IOException("Keine Datei in Version."); }
                var f0 = files.get(0).getAsJsonObject();
                String fname = f0.get("filename").getAsString();
                String dl = f0.get("url").getAsString();
                Path modsDir = Minecraft.getInstance().gameDirectory.toPath().resolve("mods");
                Files.createDirectories(modsDir);
                Path out = modsDir.resolve(fname);
                try (var in2 = new java.io.BufferedInputStream(new URL(dl).openStream());
                     var out2 = Files.newOutputStream(out)) {
                    in2.transferTo(out2);
                }
                this.minecraft.player.displayClientMessage(Component.literal("Installiert: " + fname + " (Neustart nötig)"), false);
            }
        } catch (Exception e) {
            this.minecraft.player.displayClientMessage(Component.literal("Fehler: " + e.getMessage()), false);
        }
    }

    @Override
    public boolean mouseClicked(double x, double y, int button) {
        int listX = 20;
        int listY = 90;
        int rowH = 14;
        int w = this.width - listX - 20;
        if (x >= listX && x <= listX + w && y >= listY) {
            int index = (int)((y - listY) / rowH);
            if (index >= 0 && index < results.size()) {
                selected = index;
                return true;
            }
        }
        return super.mouseClicked(x, y, button);
    }

    @Override
    public void render(net.minecraft.client.gui.GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g);
        g.drawString(this.font, this.title, 20, 15, 0xFFFFFF);
        g.drawString(this.font, "Suche Projekte auf Modrinth (Forge, 1.20.1)", 20, 65, 0xAAAAAA);
        int listX = 20, listY = 90, rowH = 14;
        for (int i = 0; i < results.size(); i++) {
            int col = (i == selected) ? 0xFFFF00 : 0xFFFFFF;
            g.drawString(this.font, results.get(i).title, listX, listY + i * rowH, col);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }

    private static class Project {
        String id; String title;
        Project(String id, String title) { this.id = id; this.title = title; }
    }
}
