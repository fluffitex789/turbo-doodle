package com.example.ingamelauncher.ui;

import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.client.Minecraft;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Collectors;

public class ModsScreen extends Screen {
    private final Screen parent;
    private List<Path> mods;
    private List<Path> disabled;
    private int selectedIndex = -1;
    private boolean viewingDisabled = false;

    private Path modsDir() {
        return Minecraft.getInstance().gameDirectory.toPath().resolve("mods");
    }
    private Path disabledDir() {
        return Minecraft.getInstance().gameDirectory.toPath().resolve("mods_disabled");
    }

    public ModsScreen(Screen parent) {
        super(Component.literal("Mods Manager"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        reloadLists();
        int btnW = 140;
        int x = 20;
        int y = 40;
        int gap = 4;

        this.addRenderableWidget(Button.builder(Component.literal("Install (Modrinth)"), b -> this.minecraft.setScreen(new ModrinthSearchScreen(this)))
            .bounds(x, y, btnW, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Toggle Enabled/Disabled"), b -> toggleSelected())
            .bounds(x, y + 24 + gap, btnW, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Remove"), b -> deleteSelected())
            .bounds(x, y + 48 + gap*2, btnW, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("View: " + (viewingDisabled ? "Disabled" : "Enabled")), b -> {
            viewingDisabled = !viewingDisabled; selectedIndex = -1; init();
        }).bounds(x, y + 72 + gap*3, btnW, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Back"), b -> this.minecraft.setScreen(parent))
            .bounds(x, this.height - 30, btnW, 20).build());
    }

    private void reloadLists() {
        try {
            Files.createDirectories(disabledDir());
            try (var s = Files.list(modsDir())) {
                mods = s.filter(p -> p.toString().endsWith(".jar")).sorted().collect(Collectors.toList());
            }
            try (var s = Files.list(disabledDir())) {
                disabled = s.filter(p -> p.toString().endsWith(".jar")).sorted().collect(Collectors.toList());
            }
        } catch (IOException e) {
            e.printStackTrace();
            mods = new ArrayList<>();
            disabled = new ArrayList<>();
        }
    }

    private List<Path> currentList() { return viewingDisabled ? disabled : mods; }

    private void toggleSelected() {
        int i = selectedIndex;
        if (i < 0) return;
        Path src = currentList().get(i);
        Path dst = viewingDisabled ? modsDir().resolve(src.getFileName()) : disabledDir().resolve(src.getFileName());
        try {
            Files.move(src, dst, StandardCopyOption.REPLACE_EXISTING);
            selectedIndex = -1;
            reloadLists();
            this.minecraft.player.displayClientMessage(Component.literal("Mod " + (viewingDisabled ? "enabled" : "disabled") + ". Neustart erforderlich."), false);
        } catch (IOException e) {
            this.minecraft.player.displayClientMessage(Component.literal("Fehler: " + e.getMessage()), false);
        }
    }

    private void deleteSelected() {
        int i = selectedIndex;
        if (i < 0) return;
        Path src = currentList().get(i);
        try {
            Files.deleteIfExists(src);
            selectedIndex = -1;
            reloadLists();
        } catch (IOException e) {
            this.minecraft.player.displayClientMessage(Component.literal("Fehler: " + e.getMessage()), false);
        }
    }

    @Override
    public boolean mouseClicked(double x, double y, int button) {
        int listX = 180;
        int listY = 40;
        int rowH = 14;
        int w = this.width - listX - 20;
        if (x >= listX && x <= listX + w && y >= listY) {
            int index = (int)((y - listY) / rowH);
            if (index >= 0 && index < currentList().size()) {
                selectedIndex = index;
                return true;
            }
        }
        return super.mouseClicked(x, y, button);
    }

    @Override
    public void render(net.minecraft.client.gui.GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g);
        g.drawString(this.font, this.title, 20, 15, 0xFFFFFF);
        g.drawString(this.font, "Hinweis: Neustart nötig nach Mod-Änderungen.", 180, 15, 0xAAAAAA);
        int listX = 180;
        int listY = 40;
        int rowH = 14;
        var list = currentList();
        for (int i = 0; i < list.size(); i++) {
            var name = list.get(i).getFileName().toString();
            int col = (i == selectedIndex) ? 0xFFFF00 : 0xFFFFFF;
            g.drawString(this.font, name, listX, listY + i * rowH, col);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }
}
