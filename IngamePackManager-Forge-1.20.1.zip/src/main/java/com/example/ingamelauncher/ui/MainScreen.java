package com.example.ingamelauncher.ui;

import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

public class MainScreen extends Screen {
    public MainScreen() {
        super(Component.literal("Ingame Pack Manager"));
    }

    @Override
    protected void init() {
        int w = this.width;
        int h = this.height;
        int y = 40;
        int btnW = 120;
        int gap = 10;

        this.addRenderableWidget(Button.builder(Component.literal("Mods"), b -> this.minecraft.setScreen(new ModsScreen(this)))
            .bounds(20, y, btnW, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Shaderpacks"), b -> this.minecraft.setScreen(new ShaderScreen(this)))
            .bounds(20, y + 22 + gap, btnW, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Datapacks"), b -> this.minecraft.setScreen(new DatapackScreen(this)))
            .bounds(20, y + 44 + gap*2, btnW, 20).build());

        this.addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose())
            .bounds(20, h - 30, btnW, 20).build());
    }

    @Override
    public void render(net.minecraft.client.gui.GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g);
        g.drawString(this.font, this.title, 20, 15, 0xFFFFFF);
        super.render(g, mouseX, mouseY, partialTick);
    }
}
