package com.example.ingamelauncher.ui;

import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.client.Minecraft;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Collectors;

public class ShaderScreen extends Screen {
    private final Screen parent;
    private List<Path> packs = new ArrayList<>();
    private int selected = -1;

    public ShaderScreen(Screen parent) {
        super(Component.literal("Shaderpacks Manager"));
        this.parent = parent;
    }

    private Path shaderDir() {
        return Minecraft.getInstance().gameDirectory.toPath().resolve("shaderpacks");
    }

    @Override
    protected void init() {
        reload();
        int x = 20; int y = 40; int btnW = 140; int gap = 4;
        this.addRenderableWidget(Button.builder(Component.literal("Reload"), b -> { reload(); }).bounds(x, y, btnW, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Remove"), b -> deleteSelected()).bounds(x, y + 24 + gap, btnW, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Back"), b -> this.minecraft.setScreen(parent)).bounds(x, this.height - 30, btnW, 20).build());
    }

    private void reload() {
        try {
            Files.createDirectories(shaderDir());
            try (var s = Files.list(shaderDir())) {
                packs = s.filter(p -> p.toString().endsWith(".zip")).sorted().collect(Collectors.toList());
            }
        } catch (IOException e) {
            packs = new ArrayList<>();
        }
    }

    private void deleteSelected() {
        if (selected < 0 || selected >= packs.size()) return;
        try {
            Files.deleteIfExists(packs.get(selected));
            selected = -1; reload();
        } catch (IOException e) {
            this.minecraft.player.displayClientMessage(Component.literal("Fehler: " + e.getMessage()), false);
        }
    }

    @Override
    public boolean mouseClicked(double x, double y, int button) {
        int listX = 180, listY = 40, rowH = 14;
        int w = this.width - listX - 20;
        if (x >= listX && x <= listX + w && y >= listY) {
            int idx = (int)((y - listY) / rowH);
            if (idx >= 0 && idx < packs.size()) { selected = idx; return true; }
        }
        return super.mouseClicked(x, y, button);
    }

    @Override
    public void render(net.minecraft.client.gui.GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g);
        g.drawString(this.font, this.title, 20, 15, 0xFFFFFF);
        g.drawString(this.font, "Hinweis: Shader benötigen Oculus/Iris o.ä. Diese Mod verwaltet nur Dateien.", 20, 65, 0xAAAAAA);
        int listX = 180, listY = 40, rowH = 14;
        for (int i = 0; i < packs.size(); i++) {
            int col = (i == selected) ? 0xFFFF00 : 0xFFFFFF;
            g.drawString(this.font, packs.get(i).getFileName().toString(), listX, listY + i * rowH, col);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }
}
