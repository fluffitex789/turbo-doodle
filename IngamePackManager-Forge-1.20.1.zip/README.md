# Ingame Pack Manager (Forge 1.20.1)

**Taste G** öffnet das UI.

## Features (MVP)
- **Mods**: Suche/Download von Modrinth (Forge & 1.20.1), De-/Aktivieren durch Verschieben .jar ↔ `mods_disabled` (Neustart nötig).
- **Shaderpacks**: Listet/verwaltet `.zip` im Ordner `shaderpacks/`. Hinweis: Shader benötigen **Oculus/Iris** o.ä.
- **Datapacks**: Listet Packs der aktuellen Welt; `/datapack enable|disable` im Singleplayer.

## Build / Run
1. Öffne das Projekt in IntelliJ (Java 17 installieren).
2. Führe `gradlew genIntellijRuns` (falls Wrapper ergänzt) oder starte den **Gradle-Task** `runClient` (über ForgeGradle).
3. Im Spiel: Drücke **G**.

> Hinweis: Der Wrapper ist hier nicht beigelegt. Du kannst lokal `gradle wrapper` ausführen, falls nötig.
