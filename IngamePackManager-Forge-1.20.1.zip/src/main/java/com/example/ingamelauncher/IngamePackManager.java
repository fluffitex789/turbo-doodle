package com.example.ingamelauncher;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraft.client.KeyMapping;
import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.glfw.GLFW;

@Mod("ingame_pack_manager")
public class IngamePackManager {
    public static final String MODID = "ingame_pack_manager";
    public static KeyMapping OPEN_UI;

    public IngamePackManager() {
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::onClientSetup);
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::registerKeys);
    }

    private void onClientSetup(final FMLClientSetupEvent event) {
        // no-op
    }

    private void registerKeys(final RegisterKeyMappingsEvent event) {
        OPEN_UI = new KeyMapping("key.ingame_pack_manager.open", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, "key.categories.misc");
        event.register(OPEN_UI);
    }

    @Mod.EventBusSubscriber(modid = MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static class ClientEvents {
        @SubscribeEvent
        public static void onClientTick(net.minecraftforge.client.event.InputEvent.Key event) {
            if (OPEN_UI != null && OPEN_UI.consumeClick()) {
                net.minecraft.client.Minecraft.getInstance().setScreen(new ui.MainScreen());
            }
        }
    }
}
